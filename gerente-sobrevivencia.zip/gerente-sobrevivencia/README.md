# Gerente de Sobrevivência 🔋

Jogo idle/tycoon onde você gerencia energia de uma casa em um cenário de escassez.
Feito com [Phaser 3](https://phaser.io/), HTML e JavaScript puro — roda em qualquer navegador.

## ✅ Status do MVP
Este é o **protótipo mínimo (MVP)** descrito no GDD:
- Recurso único: **Energia**
- Consumo e produção automáticos por "dia"
- Evento aleatório: **Apagão**
- 2 melhorias: **Painel Solar** e **Bateria**
- Tela de Game Over com reinício

## ▶️ Como rodar localmente (VSCode)

1. Abra a pasta `gerente-sobrevivencia` no VSCode.
2. Instale a extensão **Live Server** (by Ritwick Dey) na aba de extensões.
3. Clique com o botão direito em `index.html` → **"Open with Live Server"**.
4. O jogo abre no navegador. Qualquer alteração salva atualiza a página automaticamente.

> Alternativa sem extensão: só dê duplo clique no `index.html` — funciona também, mas sem auto-reload.

## 🔧 Ajustando a velocidade de teste
No arquivo `js/game.js`, mude esta linha para acelerar/desacelerar os "dias" durante os testes:
```js
const DAY_DURATION_MS = 3000; // 3 segundos = 1 dia
```

## 📦 Subindo para o GitHub

```bash
cd gerente-sobrevivencia
git init
git add .
git commit -m "MVP: primeiro protótipo jogável"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/gerente-sobrevivencia.git
git push -u origin main
```

Crie o repositório vazio antes no site do GitHub (sem README, para não dar conflito).

## 🌐 Publicando uma versão jogável online (grátis, para testar com amigos)
Repositório no GitHub → aba **Settings** → **Pages** → Source: `main` branch, pasta `/root`.
Em alguns minutos o jogo fica disponível em:
`https://SEU_USUARIO.github.io/gerente-sobrevivencia/`

Isso já resolve a etapa de **"pesquisa rápida com amigos/grupos"** do plano de validação — manda o link no Discord/Reddit e pede feedback.

## 🗺️ Próximos passos sugeridos
1. **Feedback de amigos** no link do GitHub Pages (validação da ideia).
2. Adicionar 2º recurso (Água) seguindo o mesmo padrão de `energy`/`energyCapacity`.
3. Adicionar mais eventos aleatórios (seca, inflação).
4. Trocar retângulos por sprites/arte (pode pegar em [Kenney.nl](https://kenney.nl), gratuito).
5. Salvar progresso com `localStorage` (funciona neste projeto normal — só não funciona dentro de artifacts do Claude).
6. Empacotar para Android/iOS com **Capacitor** (`npx cap init`, `npx cap add android`) quando o protótipo estiver validado.
7. Adicionar anúncios (AdMob) e loja (IAP) só depois do empacotamento nativo.

## 📁 Estrutura do projeto
```
gerente-sobrevivencia/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── game.js
└── README.md
```
